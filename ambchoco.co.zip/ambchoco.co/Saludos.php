<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ambchocó</title>

    <!-- Favicon -->
    <link rel="icon" href="favicon/android-icon-36x36.png">

    <!-- Bootstrap & Font‑Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/2.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
          integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <!-- ====================== CONTENIDO PRINCIPAL ====================== -->
    <div id="body-subir">

        <!-- ====================== NAVBAR ====================== -->
        <nav class="navbar navbar-expand-lg bg-light p-2 text-success fixed-top">
            <div class="container-fluid">
                <a href="#">
                    <img id="logo" src="img/logo.png" alt="logo">
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="menu">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="Saludos.php" class="nav-link">
                                <i class="fa-solid fa-house"></i> Inicio
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="sobre-nosotros.php" class="nav-link">
                                <i class="fa-solid fa-magnifying-glass"></i> Sobre nosotros
                            </a>
                        </li>

                        <!-- ========= Contenido dropdown ========= -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-plus"></i> Contenido
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Noticias y artículos</a></li>
                                <li><a class="dropdown-item" href="#">Temas educativos</a></li>
                                <li><a class="dropdown-item" href="#">Test</a></li>
                            </ul>
                        </li>

                        <!-- ========= Menú informativo dropdown ========= -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-book"></i> Menú informativo
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item" href="#">Ambiente: ¿Qué es?, importancia, características</a>
                                </li>

                                <!-- Sub‑dropdown -->
                                <li class="dropdown-submenu position-relative">
                                    <a class="dropdown-item dropdown-toggle" href="#">Más temas</a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#">Contaminación: Agua, Aire y Suelo</a></li>
                                        <li><a class="dropdown-item" href="#">Residuos sólidos</a></li>
                                        <li><a class="dropdown-item" href="#">Deforestación</a></li>
                                        <li><a class="dropdown-item" href="#">Minería ilegal</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>

                        <li class="nav-item">
                            <a href="Form-inicioSesion.php" class="nav-link">
                                <i class="fa-solid fa-door-open"></i> Crear cuenta
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- ====================== CARRUSEL PRINCIPAL ====================== -->
        <main class="container-fluid p-0">
            <div class="row">
                <div class="col">
                    <div id="slideshow" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="img/banner.png" class="w-100" alt="Banner del logo">
                            </div>
                            <div class="carousel-item">
                                <img src="img/floryanimal.png" class="w-100" alt="Comunicación">
                            </div>
                            <div class="carousel-item">
                                <img src="img/personas.png" class="w-100" alt="Cuidado">
                            </div>
                        </div>

                        <!-- Controles -->
                        <button class="carousel-control-prev" type="button" data-bs-target="#slideshow" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Anterior</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#slideshow" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Siguiente</span>
                        </button>

                        <!-- Indicadores -->
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#slideshow" data-bs-slide-to="0"
                                    class="active" aria-current="true" aria-label="slide 1"></button>
                            <button type="button" data-bs-target="#slideshow" data-bs-slide-to="1"
                                    aria-label="slide 2"></button>
                            <button type="button" data-bs-target="#slideshow" data-bs-slide-to="2"
                                    aria-label="slide 3"></button>
                        </div>
                    </div>
                </div>
            </div>
        </main><br><br>

        <!-- ====================== SOBRE NOSOTROS ====================== -->
        <section class="container-fluid py-6 px-5" id="sobre-nosotros">
            <div class="row align-items-center contenedor">
                <!-- Texto -->
                <div class="col-lg-8 col-md-12">
                    <h1>Sobre Nosotros</h1>
                    <p>
                        ¡Bienvenido a Ambchocó!<br>
                        Aquí encontrarás temas de cuidado del medio ambiente relacionados con el Chocó, noticias,
                        artículos e información para ayudar a un ambiente mejor, no solo del Chocó, sino del mundo
                        entero.<br><br>
                        Somos un equipo comprometido con la educación, la conservación y la acción ambiental,
                        dedicado a inspirar a personas de todas las edades a tomar decisiones más sostenibles.
                    </p>
                    <h4>Recuerda: Sé consciente, sé ecológico, actúa en acción.</h4>
                </div>

                <!-- Imagen -->
                <div class="col-lg-4 col-md-12">
                    <img src="img/descarga.jpg" alt="Planta"
                         class="img-fluid rounded-circle" title="Imagen de Planta">
                </div>
            </div>
        </section><br><br>

        <!-- ====================== COMENTARIOS / TESTIMONIOS ====================== -->
        <section class="container-fluid py-6 px-5" id="comentarios"><br>
            <div class="row align-items-center contenedor1">
                <h2>Sección de comentarios o testimonios</h2>

                <!-- Formulario -->
                <div class="col-lg-8 col-md-12">
                    <form method="post" action="config.php/proceso-c.php" class="my-4">

                        <div class="mb-3">
                            <label class="form-label">Agregue su opinión</label>
                            <textarea rows="5" class="form-control" name="comentario" style="width: 990px;"></textarea>
                        </div>

                        <button type="submit" name="enviar" class="btn btn-success">
                            Enviar comentario
                        </button>
                    </form>
                </div>
            </div><!-- FIN .row -->
        </section><!-- FIN sección comentarios -->
    </div><!-- FIN #body-subir -->

    <!-- ====================== FOOTER ====================== -->
    <footer>
        <div class="footer-container">
            <div class="footer-column">
                <div class="Titulo-footer">Ambchocó.com</div>
                <a class="enlace-footer" href="#">Acerca de</a>
                <a class="enlace-footer" href="#">Términos y condiciones</a>
            </div>

            <div class="footer-column">
                <a class="enlace-footer2" href="#">Política y privacidad</a>
                <a class="enlace-footer2" href="#">Perfil</a>
            </div>

            <div class="footer-column">
                <a class="enlace-footer1" href="https://www.facebook.com/profile.php?id=100065455431040">Facebook</a>
                <a class="enlace-footer1" href="https://www.youtube.com/@Tatiliaxd123">YouTube</a>
            </div>

            <div class="footer-column">
                <a class="btn btn-link enlace-footer2" href="#body-subir">Subir página</a>
                <a id="enlace-footer3" class="btn btn-link" href="#">
                    <img src="img/logo.png" alt="logo" class="w-50 img-fluid">
                </a>
            </div>
        </div>

        <h4 class="footer-final mb-0">© 2025 Ambchocó.com</h4>
    </footer>

    <!-- ====================== SCRIPTS ====================== -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
