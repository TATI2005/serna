<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Sidebar con Footer</title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Admin1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

  <!-- Sidebar -->
  <div id="sidebar">
    <a class="nav-link" href="#"><h6>Inicio</h6></a>
    <a class="nav-link" href="#"><h6>Usuarios</h6></a>
    <a class="nav-link" href="#"><h6>Crear Noticias</h6></a>
     <a class="nav-link" href="#"><h6>Quiz o test</h6></a>
    <a class="nav-link" href="#"><h6>Visualizacion de comentarios</h6></a>
    <a class="nav-link" href="#"><h6>Salir</h6></a>
  </div>

  <!-- Contenido principal -->
  <div id="main-content">
    <h1>Bienvenida a LAiKa</h1>
    <p>Aquí va el contenido principal de la página.</p>
  </div>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 LAika | Todos los derechos reservados de LAiKa company</p>
  </footer>

</body>
</html>
